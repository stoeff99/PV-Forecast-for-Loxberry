Please copy your plugin icons here. Please provide icons in PNG fileformat
with transparency and in the following sizes:

  * Size:  64 x  64
  * Size: 128 x 128
  * Size: 256 x 256
  * Size: 512 x 512

Use the same filenames like the sample files!

To have a unique Look & Feel you may use one of the standard icons as basis 
for your own icon: 

http://download.loxberry.de/development/icons/